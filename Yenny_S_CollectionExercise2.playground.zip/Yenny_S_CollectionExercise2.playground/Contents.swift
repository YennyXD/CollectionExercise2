import UIKit

var ownCollection = ["I like to collect"]

ownCollection.append("Amethyst")
ownCollection.append("Tiger's eye")
ownCollection.append("Rose quartz")
ownCollection.append("Clear quartz")
ownCollection.append("Malachite")

ownCollection.sort()

print(ownCollection)
